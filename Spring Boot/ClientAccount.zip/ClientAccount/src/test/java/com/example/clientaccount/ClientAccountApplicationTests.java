package com.example.clientaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientAccountApplicationTests {

    @Test
    void contextLoads() {
    }

}
