package com.example.clientaccount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientAccountApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClientAccountApplication.class, args);
    }

}
