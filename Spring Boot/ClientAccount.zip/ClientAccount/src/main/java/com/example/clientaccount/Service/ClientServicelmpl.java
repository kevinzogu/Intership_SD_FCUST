package com.example.clientaccount.Service;

import com.example.clientaccount.Model.Client;
import com.example.clientaccount.Repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public class ClientServicelmpl implements ClientService {

    @Autowired
    private ClientRepository clientRepository;

    @Override
    public Client createClient(Client client) {
        return clientRepository.save(client);
    }

    @Override
    public Client updateClient(Client client) {
        Optional<Client> clientDB = this.clientRepository.findById(client.getId());
        if (clientDB.isPresent()) {
            Client clientUpdate = clientDB.get();
            clientUpdate.setId(client.getId());
            clientUpdate.setNo(client.getNo());
            clientUpdate.setName(client.getName());
            clientUpdate.setPhone_nr(client.getPhone_nr());
            clientUpdate.setEmail(client.getEmail());
            clientUpdate.setType(client.getType());
            clientUpdate.setCategory(client.getCategory());
            clientRepository.save(clientUpdate);
            return clientUpdate;
        }
    }

    @Override
    public List<Client> getAllClient() {
        return null;
    }

    @Override
    public Client getClientById(Long clienId) {
        return null;
    }

    @Override
    public void deleteClient(long id) {

    }
}
